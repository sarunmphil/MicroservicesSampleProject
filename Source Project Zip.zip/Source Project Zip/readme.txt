use spring initializr to generate maven projects online
use maven repository to generate pom config
