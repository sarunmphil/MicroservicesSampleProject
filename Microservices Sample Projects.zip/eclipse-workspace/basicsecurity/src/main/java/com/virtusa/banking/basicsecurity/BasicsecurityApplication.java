package com.virtusa.banking.basicsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicsecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicsecurityApplication.class, args);
	}
}
