package com.virtusa.banking.ZuulDemo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ZuulDemoApplicationTests {

	@Test
	public void contextLoads() {
	}

}
