package com.virtusa.banking.repository;

import org.springframework.data.annotation.QueryAnnotation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.virtusa.banking.model.Customer;

@Repository 
public interface CustomerRepository extends JpaRepository<Customer, Long> 
{
	@Query("delete from Customer cust where cust.firstName= :fname")
	public void deleteByName(@Param("fname") String fname);
	
}
