package com.virtusa.banking.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.banking.model.Customer;
import com.virtusa.banking.repository.CustomerRepository;
import com.virtusa.banking.services.CustomerService;

@RestController
public class Kyccontroller {

	@Autowired
	private CustomerService service;
	
	@GetMapping("/")
	public String home()
	{
		for(int i=0; i<100000; i++) {
			System.out.print("Ready to rock1");		 
		}
		return "hello";
	}
	
	
	@GetMapping("/Customers")
	public List<Customer> GetAllCustomers()
	{
		return service.getAllCustomers();
	}
	@RequestMapping(path="/Customer/{id}",method = RequestMethod.GET)
	public Customer GetCustomers(@PathVariable  Long id)
	{
		
		return service.customerFindById(id);
		
	}
	
	@PostMapping("/Customer")
	public @ResponseBody Customer addCustomerData(@RequestBody Customer customer)
	{
		return service.saveCustomer(customer);
	}
	
	@RequestMapping(path="/Customer/{id}",method = RequestMethod.DELETE)
	//also can give @DeleteMapping so no path required
	public void deleteCustomerData(@PathVariable Long id)
	{
		 service.deleteCustomer(id); 
	}
	
	@RequestMapping(path="/Customers/{firstName}",method = RequestMethod.DELETE)
	//also can give @DeleteMapping so no path required
	public void deleteCustomerByName(@PathVariable String firstName)
	{
		 service.deleteCustomerByName(firstName);		 
	}
	
	
	
	
}
