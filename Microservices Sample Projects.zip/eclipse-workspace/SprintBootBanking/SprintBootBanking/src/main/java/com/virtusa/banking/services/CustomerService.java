package com.virtusa.banking.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.virtusa.banking.model.Customer;
import com.virtusa.banking.repository.CustomerRepository;

@Service
public class CustomerService  
{

	@Autowired
	private CustomerRepository repo;
	
	//save object
	public Customer saveCustomer(Customer customer)
	{
		return repo.save(customer);		
	}
	
	//retrieve all
	public java.util.List<Customer> getAllCustomers()
	{
		return repo.findAll();		
	}
	
	//find by id
	public Customer customerFindById(long id)
	{
		return repo.findById(id).orElse(null);		
	}	

	//delete customer by id
	public void deleteCustomer(long id)
	{
		 repo.deleteById(id);		
	}
	
		//delete customer by fname
		public void deleteCustomerByName(String fname)
		{
			 repo.deleteByName(fname);		
		}
	
	
}
