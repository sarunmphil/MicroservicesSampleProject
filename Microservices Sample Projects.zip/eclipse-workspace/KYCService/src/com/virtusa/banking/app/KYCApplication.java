package com.virtusa.banking.app;
import org.springframework.boot.SpringApplication;

public class KYCApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.out.print("Hello World");
			SpringApplication.run()
	}

}
