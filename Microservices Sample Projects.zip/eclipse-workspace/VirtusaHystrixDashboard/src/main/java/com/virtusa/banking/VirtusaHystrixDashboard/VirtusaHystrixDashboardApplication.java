package com.virtusa.banking.VirtusaHystrixDashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VirtusaHystrixDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtusaHystrixDashboardApplication.class, args);
	}
}
