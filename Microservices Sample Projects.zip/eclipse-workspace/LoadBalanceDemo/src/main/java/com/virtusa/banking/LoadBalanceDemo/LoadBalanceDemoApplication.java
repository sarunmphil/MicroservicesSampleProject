package com.virtusa.banking.LoadBalanceDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoadBalanceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoadBalanceDemoApplication.class, args);
	}
}
